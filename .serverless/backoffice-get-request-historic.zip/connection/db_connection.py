import sys
#sys.path.insert(0, 'vendor')

import os
import pg8000


DB_ENDPOINT = os.environ['DB_ENDPOINT']
DB_USERNAME = os.environ['DB_USERNAME']
DB_PASSWORD = os.environ['DB_PASSWORD']
DB_DATABASE = os.environ['DB_DATABASE']

#DB_ENDPOINT = "confa.cfkwry6gcjvj.us-east-1.rds.amazonaws.com"
#DB_USERNAME = "postgres"
#DB_PASSWORD = "c4nf4_pqr"
#DB_DATABASE = "confa"

def connect_to_database():
    try:
        conn = pg8000.connect(
        host=DB_ENDPOINT,
        database=DB_DATABASE,
        user=DB_USERNAME,
        password=DB_PASSWORD)
        return conn
    except Exception as e:
        print(str(e))
        return None